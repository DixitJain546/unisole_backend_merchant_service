package com.example.MerchantService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MerchantServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
