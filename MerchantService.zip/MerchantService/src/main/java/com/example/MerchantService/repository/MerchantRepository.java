package com.example.MerchantService.repository;

import com.example.MerchantService.entity.MerchantStore;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MerchantRepository extends JpaRepository<MerchantStore,String> {
}
