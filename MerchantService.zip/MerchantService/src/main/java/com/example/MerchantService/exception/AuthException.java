package com.example.MerchantService.exception;

public class AuthException extends Exception {
    public AuthException(String message) {
        super(message);
    }
}
