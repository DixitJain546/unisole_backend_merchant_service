package com.example.MerchantService.services;

import com.example.MerchantService.entity.MerchantStore;
import com.example.MerchantService.repository.MerchantRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MerchantRegistrationServiceImpl implements MerchantRegistrationService{
    @Autowired
    MerchantRepository merchantRepository;
    @Override
    public MerchantStore registerStore(MerchantStore merchantStore) {
        return merchantRepository.save(merchantStore);
    }

    @Override
    public MerchantStore getMerchantStoreById(String merchantId) {
        return merchantRepository.findById(merchantId).get();
    }
}
